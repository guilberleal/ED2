void DFS_aux(GRAFO *G, int u){
    VERTICE *v;
    cor[u] = CINZA;
    tempo = tempo + 1;
    d[u] = tempo;
    for(v = G->adj[u]; v != NULL; v = v->cab){
        if(cor[v] == BRANCO){
            pred[v] = u;
            DFS_aux(G,v);
        }
    }
    cor[u] = PRETO;
    tempo = tempo + 1;
    f[u] = tempo;
}

void DFS_recursivo(GRAFO *G, int raiz){
    for(v = G->vertices; v < G->vertices + G->arestas; v++){
        cor[v] = BRANCO;
        pref[v] = NULL;
    }
    tempo = 0;
    for(v = G->vertices; v < G->vertices + G->arestas; v++){
        if(cor[v] == BRANCO){
            DFS_aux(G, raiz);
        }
    }
}